package com.ptit.springbootdepartmentstore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootDepartmentStoreTests {

	@Test
	void contextLoads() {
	}

}
