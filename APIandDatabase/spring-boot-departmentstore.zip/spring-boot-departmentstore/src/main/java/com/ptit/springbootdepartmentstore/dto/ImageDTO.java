package com.ptit.springbootdepartmentstore.dto;

import lombok.Data;

@Data
public class ImageDTO {
	
    private Integer id;
    
    private String imageBase64;
    
}
